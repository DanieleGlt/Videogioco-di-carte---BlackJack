import { GameState, Card, Player, GameAction } from '../types';
import { createDeck, dealCard, calculateScore, isBlackjack, isBusted } from './cardUtils';

export const initializeGame = (chips = 1000): GameState => {
  const deck = createDeck();
  
  return {
    deck,
    player: {
      hand: [],
      score: 0,
      hasBlackjack: false,
      busted: false,
    },
    dealer: {
      hand: [],
      score: 0,
      hasBlackjack: false,
      busted: false,
    },
    currentBet: 0,
    chips,
    gameStatus: 'betting',
    message: 'Fai la tua puntata!',
    history: {
      wins: 0,
      losses: 0,
      blackjacks: 0,
      pushes: 0,
    },
  };
};

export const startNewRound = (state: GameState, bet: number): GameState => {
  if (bet > state.chips) {
    return {
      ...state,
      message: 'Fiches insufficienti!',
    };
  }

  if (bet <= 0) {
    return {
      ...state,
      message: 'Devi fare una puntata!',
    };
  }

  const deck = state.deck.length < 10 ? createDeck() : state.deck;
  
  let [playerCard1, deck1] = dealCard(deck);
  let [dealerCard1, deck2] = dealCard(deck1);
  let [playerCard2, deck3] = dealCard(deck2);
  let [dealerCard2, deck4] = dealCard(deck3, true);
  
  const playerHand = [playerCard1, playerCard2];
  const dealerHand = [dealerCard1, dealerCard2];
  
  const playerScore = calculateScore(playerHand);
  const dealerScore = calculateScore(dealerHand);
  
  const playerHasBlackjack = isBlackjack(playerHand);
  const dealerHasBlackjack = isBlackjack([dealerHand[0], { ...dealerHand[1], hidden: false }]);
  
  let gameStatus = 'playing';
  let message = 'Carta o Stai?';
  let newChips = state.chips - bet;
  
  if (playerHasBlackjack) {
    if (dealerHasBlackjack) {
      gameStatus = 'gameOver';
      message = 'Pareggio! Entrambi Blackjack.';
      newChips += bet;
      
      return {
        ...state,
        deck: deck4,
        player: {
          hand: playerHand,
          score: playerScore,
          hasBlackjack: true,
          busted: false,
        },
        dealer: {
          hand: [
            dealerHand[0],
            { ...dealerHand[1], hidden: false },
          ],
          score: calculateScore([dealerHand[0], { ...dealerHand[1], hidden: false }]),
          hasBlackjack: true,
          busted: false,
        },
        currentBet: bet,
        chips: newChips,
        gameStatus,
        message,
        history: {
          ...state.history,
          pushes: state.history.pushes + 1,
        },
      };
    } else {
      gameStatus = 'gameOver';
      message = 'Blackjack! Hai vinto!';
      newChips += bet + (bet * 1.5);
      
      return {
        ...state,
        deck: deck4,
        player: {
          hand: playerHand,
          score: playerScore,
          hasBlackjack: true,
          busted: false,
        },
        dealer: {
          hand: [
            dealerHand[0],
            { ...dealerHand[1], hidden: false },
          ],
          score: calculateScore([dealerHand[0], { ...dealerHand[1], hidden: false }]),
          hasBlackjack: false,
          busted: false,
        },
        currentBet: bet,
        chips: newChips,
        gameStatus,
        message,
        history: {
          ...state.history,
          wins: state.history.wins + 1,
          blackjacks: state.history.blackjacks + 1,
        },
      };
    }
  }
  
  return {
    ...state,
    deck: deck4,
    player: {
      hand: playerHand,
      score: playerScore,
      hasBlackjack: false,
      busted: false,
    },
    dealer: {
      hand: dealerHand,
      score: dealerScore,
      hasBlackjack: false,
      busted: false,
    },
    currentBet: bet,
    chips: newChips,
    gameStatus,
    message,
  };
};

export const hit = (state: GameState): GameState => {
  if (state.gameStatus !== 'playing') {
    return state;
  }
  
  const [newCard, newDeck] = dealCard(state.deck);
  const newHand = [...state.player.hand, newCard];
  const newScore = calculateScore(newHand);
  const busted = isBusted(newHand);
  
  if (busted) {
    return {
      ...state,
      deck: newDeck,
      player: {
        ...state.player,
        hand: newHand,
        score: newScore,
        busted,
      },
      dealer: {
        ...state.dealer,
        hand: state.dealer.hand.map(card => ({ ...card, hidden: false })),
        score: calculateScore(state.dealer.hand.map(card => ({ ...card, hidden: false }))),
      },
      gameStatus: 'gameOver',
      message: 'Sballato! Hai perso.',
      history: {
        ...state.history,
        losses: state.history.losses + 1,
      },
    };
  }
  
  return {
    ...state,
    deck: newDeck,
    player: {
      ...state.player,
      hand: newHand,
      score: newScore,
    },
    message: newScore === 21 ? 'Stai con 21?' : 'Carta o Stai?',
  };
};

export const stand = (state: GameState): GameState => {
  if (state.gameStatus !== 'playing') {
    return state;
  }
  
  const revealedDealerHand = state.dealer.hand.map(card => ({ ...card, hidden: false }));
  const dealerScore = calculateScore(revealedDealerHand);
  
  return dealerTurn({
    ...state,
    dealer: {
      ...state.dealer,
      hand: revealedDealerHand,
      score: dealerScore,
    },
    gameStatus: 'dealerTurn',
  });
};

export const doubleDown = (state: GameState): GameState => {
  if (state.gameStatus !== 'playing' || state.player.hand.length !== 2 || state.currentBet > state.chips) {
    return state;
  }
  
  const newBet = state.currentBet * 2;
  const newChips = state.chips - state.currentBet;
  
  const [newCard, newDeck] = dealCard(state.deck);
  const newHand = [...state.player.hand, newCard];
  const newScore = calculateScore(newHand);
  const busted = isBusted(newHand);
  
  if (busted) {
    return {
      ...state,
      deck: newDeck,
      player: {
        ...state.player,
        hand: newHand,
        score: newScore,
        busted,
      },
      dealer: {
        ...state.dealer,
        hand: state.dealer.hand.map(card => ({ ...card, hidden: false })),
        score: calculateScore(state.dealer.hand.map(card => ({ ...card, hidden: false }))),
      },
      currentBet: newBet,
      chips: newChips,
      gameStatus: 'gameOver',
      message: 'Sballato! Hai perso.',
      history: {
        ...state.history,
        losses: state.history.losses + 1,
      },
    };
  }
  
  const revealedDealerHand = state.dealer.hand.map(card => ({ ...card, hidden: false }));
  const dealerScore = calculateScore(revealedDealerHand);
  
  return dealerTurn({
    ...state,
    deck: newDeck,
    player: {
      ...state.player,
      hand: newHand,
      score: newScore,
    },
    dealer: {
      ...state.dealer,
      hand: revealedDealerHand,
      score: dealerScore,
    },
    currentBet: newBet,
    chips: newChips,
    gameStatus: 'dealerTurn',
  });
};

export const dealerTurn = (state: GameState): GameState => {
  if (state.gameStatus !== 'dealerTurn') {
    return state;
  }
  
  let currentState = { ...state };
  let dealerHand = [...currentState.dealer.hand];
  let deck = [...currentState.deck];
  
  while (calculateScore(dealerHand) < 17) {
    const [newCard, newDeck] = dealCard(deck);
    dealerHand = [...dealerHand, newCard];
    deck = newDeck;
  }
  
  const dealerScore = calculateScore(dealerHand);
  const dealerBusted = isBusted(dealerHand);
  const playerScore = currentState.player.score;
  
  let message = '';
  let gameStatus = 'gameOver';
  let newChips = currentState.chips;
  let history = { ...currentState.history };
  
  if (dealerBusted) {
    message = 'Il banco ha sballato! Hai vinto!';
    newChips += currentState.currentBet * 2;
    history.wins += 1;
  } else if (dealerScore < playerScore) {
    message = 'Hai vinto!';
    newChips += currentState.currentBet * 2;
    history.wins += 1;
  } else if (dealerScore > playerScore) {
    message = 'Il banco vince!';
    history.losses += 1;
  } else {
    message = 'Pareggio!';
    newChips += currentState.currentBet;
    history.pushes += 1;
  }
  
  return {
    ...currentState,
    deck,
    dealer: {
      ...currentState.dealer,
      hand: dealerHand,
      score: dealerScore,
      busted: dealerBusted,
    },
    chips: newChips,
    gameStatus,
    message,
    history,
  };
};

export const handleGameAction = (state: GameState, action: GameAction, bet?: number): GameState => {
  switch (action) {
    case 'hit':
      return hit(state);
    case 'stand':
      return stand(state);
    case 'double':
      return doubleDown(state);
    case 'deal':
      return bet ? startNewRound(state, bet) : state;
    case 'newGame':
      return initializeGame(state.chips > 0 ? state.chips : 1000);
    default:
      return state;
  }
};