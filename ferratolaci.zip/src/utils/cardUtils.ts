import { Card, Suit, Rank } from '../types';

// Create a new deck of cards
export const createDeck = (): Card[] => {
  const suits: Suit[] = ['hearts', 'diamonds', 'clubs', 'spades'];
  const ranks: Rank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck: Card[] = [];

  for (const suit of suits) {
    for (const rank of ranks) {
      deck.push({
        suit,
        rank,
        value: getCardValue(rank),
      });
    }
  }

  return shuffle(deck);
};

// Get the value of a card
export const getCardValue = (rank: Rank): number => {
  if (rank === 'A') return 11;
  if (rank === 'J' || rank === 'Q' || rank === 'K') return 10;
  return parseInt(rank, 10);
};

// Shuffle a deck of cards
export const shuffle = (deck: Card[]): Card[] => {
  const newDeck = [...deck];
  for (let i = newDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
  }
  return newDeck;
};

// Calculate the score of a hand
export const calculateScore = (hand: Card[]): number => {
  let score = 0;
  let aces = 0;

  for (const card of hand) {
    if (!card.hidden) {
      score += card.value;
      if (card.rank === 'A') {
        aces++;
      }
    }
  }

  // Adjust for aces
  while (score > 21 && aces > 0) {
    score -= 10;
    aces--;
  }

  return score;
};

// Check if a hand is a blackjack
export const isBlackjack = (hand: Card[]): boolean => {
  return hand.length === 2 && calculateScore(hand) === 21;
};

// Check if a hand has busted
export const isBusted = (hand: Card[]): boolean => {
  return calculateScore(hand) > 21;
};

// Get a random card from the deck
export const dealCard = (deck: Card[], hidden = false): [Card, Card[]] => {
  const newDeck = [...deck];
  const card = newDeck.pop()!;
  card.hidden = hidden;
  return [card, newDeck];
};

// Get the CSS class for a card suit
export const getSuitClass = (suit: Suit): string => {
  switch (suit) {
    case 'hearts':
      return 'text-red-500';
    case 'diamonds':
      return 'text-red-500';
    case 'clubs':
      return 'text-blue-500';
    case 'spades':
      return 'text-blue-500';
    default:
      return '';
  }
};

// Get the symbol for a card suit
export const getSuitSymbol = (suit: Suit): string => {
  switch (suit) {
    case 'hearts':
      return '♥';
    case 'diamonds':
      return '♦';
    case 'clubs':
      return '♣';
    case 'spades':
      return '♠';
    default:
      return '';
  }
};

// Check if card should be red
export const isRedSuit = (suit: Suit): boolean => {
  return suit === 'hearts' || suit === 'diamonds';
};