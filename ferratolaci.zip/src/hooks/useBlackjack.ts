import { useState, useEffect } from 'react';
import { GameState, GameAction } from '../types';
import { initializeGame, handleGameAction } from '../utils/gameLogic';

const STORAGE_KEY = 'blackjack-game-state';

export const useBlackjack = () => {
  // Initialize game state from localStorage or create a new game
  const [gameState, setGameState] = useState<GameState>(() => {
    const savedState = localStorage.getItem(STORAGE_KEY);
    return savedState ? JSON.parse(savedState) : initializeGame();
  });
  
  const [bet, setBet] = useState<number>(10);
  const [animatingCard, setAnimatingCard] = useState<boolean>(false);
  
  // Save game state to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
  }, [gameState]);
  
  // Handle game actions
  const dispatch = (action: GameAction) => {
    setAnimatingCard(true);
    setTimeout(() => {
      setGameState(prevState => 
        handleGameAction(prevState, action, action === 'deal' ? bet : undefined)
      );
      setAnimatingCard(false);
    }, 300);
  };
  
  // Reset game with fresh chips
  const resetGame = () => {
    setGameState(initializeGame());
  };
  
  // Handle betting
  const handleBet = (amount: number) => {
    setBet(prev => {
      const newBet = prev + amount;
      return newBet > 0 ? newBet : 0;
    });
  };
  
  return {
    gameState,
    bet,
    animatingCard,
    dispatch,
    handleBet,
    resetGame,
  };
};