export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

export interface Card {
  suit: Suit;
  rank: Rank;
  value: number;
  hidden?: boolean;
}

export interface Player {
  hand: Card[];
  score: number;
  hasBlackjack: boolean;
  busted: boolean;
}

export interface GameState {
  deck: Card[];
  player: Player;
  dealer: Player;
  currentBet: number;
  chips: number;
  gameStatus: 'betting' | 'playing' | 'dealerTurn' | 'gameOver';
  message: string;
  history: {
    wins: number;
    losses: number;
    blackjacks: number;
    pushes: number;
  };
}

export type GameAction = 'hit' | 'stand' | 'double' | 'deal' | 'newGame';