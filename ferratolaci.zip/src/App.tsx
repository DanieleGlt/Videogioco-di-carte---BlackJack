import React from 'react';
import Game from './components/Game';
import { Camera } from 'lucide-react';

function App() {
  const handleScreenshot = () => {
    const gameArea = document.querySelector('.game-area') as HTMLElement;
    if (!gameArea) return;

    import('html2canvas').then((html2canvas) => {
      html2canvas.default(gameArea).then((canvas) => {
        canvas.toBlob((blob) => {
          if (!blob) return;
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.download = 'blackjack-screenshot.png';
          link.href = url;
          link.click();
          URL.revokeObjectURL(url);
        });
      });
    });
  };

  return (
    <div className="h-screen flex overflow-hidden">
      <main className="flex-1">
        <div className="game-area h-full relative">
          <div className="table h-full w-full p-8">
            <div className="absolute top-4 right-4 z-50">
              <button
                onClick={handleScreenshot}
                className="bg-black/30 hover:bg-black/40 p-3 rounded-full transition-all duration-300 hover:scale-110"
                title="Screenshot"
              >
                <Camera className="w-6 h-6 text-white" />
              </button>
            </div>
            <Game />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;