import React from 'react';
import { GameAction } from '../types';

interface BettingControlsProps {
  bet: number;
  chips: number;
  onBetChange: (amount: number) => void;
  onDeal: () => void;
}

const BettingControls: React.FC<BettingControlsProps> = ({ bet, chips, onBetChange, onDeal }) => {
  const chipValues = [5, 25, 100, 500];
  
  const canDeal = bet > 0 && bet <= chips;
  
  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-4 items-center">
        <button
          className="chip bg-red-600 hover:bg-red-700 text-white font-bold flex items-center justify-center shadow-lg transform hover:scale-105 transition-all"
          onClick={() => onBetChange(-bet)}
        >
          Azzera
        </button>
        
        {chipValues.map((value) => (
          <button
            key={value}
            className={`
              chip relative transform transition-all
              ${value <= chips ? 'cursor-pointer' : 'opacity-50 cursor-not-allowed'}
              ${value === 5 ? 'chip-red' : ''}
              ${value === 25 ? 'chip-blue' : ''}
              ${value === 100 ? 'chip-green' : ''}
              ${value === 500 ? 'chip-purple' : ''}
            `}
            onClick={() => value <= chips && onBetChange(value)}
            disabled={value > chips}
          >
            <span className="absolute inset-0 flex items-center justify-center text-white font-bold text-lg">
              ${value}
            </span>
          </button>
        ))}
      </div>
      
      <div className="flex items-center gap-6">
        <div className="bg-black bg-opacity-50 backdrop-blur-sm text-white px-8 py-4 rounded-xl shadow-inner border border-white border-opacity-10">
          <span className="text-yellow-400 font-bold text-2xl">Puntata: ${bet}</span>
        </div>
        
        <button
          className={`
            px-8 py-4 rounded-xl font-bold text-xl text-white shadow-lg transform transition-all duration-300
            ${canDeal 
              ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-500 hover:to-green-600 hover:scale-105 active:scale-95 button-wow enabled green' 
              : 'bg-gray-600 bg-opacity-50 cursor-not-allowed button-wow disabled'}
          `}
          onClick={onDeal}
          disabled={!canDeal}
        >
          Distribuisci
        </button>
      </div>
    </div>
  );
};

export default BettingControls;