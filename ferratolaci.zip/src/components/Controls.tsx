import React from 'react';
import { GameAction } from '../types';

interface ControlsProps {
  onAction: (action: GameAction) => void;
  gameStatus: string;
  canDouble: boolean;
}

const Controls: React.FC<ControlsProps> = ({ onAction, gameStatus, canDouble }) => {
  const isPlaying = gameStatus === 'playing';
  
  const buttonClass = (enabled: boolean) => `
    px-6 py-3 rounded-lg font-medium text-white shadow-lg transform transition-all duration-300
    ${enabled 
      ? 'hover:scale-105 hover:shadow-xl active:scale-95' 
      : 'opacity-50 cursor-not-allowed'}
  `;
  
  return (
    <div className="flex flex-wrap justify-center gap-4 mt-6">
      <button
        className={`${buttonClass(isPlaying)} bg-green-600 hover:bg-green-700 button-wow enabled green`}
        onClick={() => onAction('hit')}
        disabled={!isPlaying}
      >
        Carta
      </button>
      
      <button
        className={`${buttonClass(isPlaying)} bg-red-600 hover:bg-red-700 button-wow enabled red`}
        onClick={() => onAction('stand')}
        disabled={!isPlaying}
      >
        Stai
      </button>
      
      <button
        className={`${buttonClass(isPlaying && canDouble)} bg-yellow-600 hover:bg-yellow-700 button-wow enabled yellow`}
        onClick={() => onAction('double')}
        disabled={!(isPlaying && canDouble)}
      >
        Raddoppia
      </button>
      
      {gameStatus === 'gameOver' && (
        <button
          className={`${buttonClass(true)} bg-blue-600 hover:bg-blue-700 button-wow enabled blue`}
          onClick={() => onAction('deal')}
        >
          Nuova Mano
        </button>
      )}
      
      {gameStatus === 'gameOver' && (
        <button
          className={`${buttonClass(true)} bg-purple-600 hover:bg-purple-700 button-wow enabled purple`}
          onClick={() => onAction('newGame')}
        >
          Nuovo Gioco
        </button>
      )}
    </div>
  );
};

export default Controls;