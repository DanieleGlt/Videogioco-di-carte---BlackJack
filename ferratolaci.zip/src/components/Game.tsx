import React, { useEffect } from 'react';
import { useBlackjack } from '../hooks/useBlackjack';
import Hand from './Hand';
import Controls from './Controls';
import BettingControls from './BettingControls';
import Message from './Message';
import { Coins, Trophy, Crown, Target } from 'lucide-react';

const Game: React.FC = () => {
  const { 
    gameState, 
    bet, 
    animatingCard,
    dispatch, 
    handleBet, 
    resetGame 
  } = useBlackjack();
  
  const { 
    player, 
    dealer, 
    chips, 
    currentBet, 
    gameStatus, 
    message, 
    history 
  } = gameState;
  
  const canDouble = player.hand.length === 2 && chips >= currentBet;
  
  useEffect(() => {
    document.title = "Blackjack - Casinò Reale";
  }, []);
  
  const handleDeal = () => {
    dispatch('deal');
  };

  const stats = [
    {
      icon: <Coins className="w-5 h-5" />,
      label: 'Fiches',
      value: `$${chips}`,
      color: 'from-yellow-600 to-yellow-700',
    },
    {
      icon: <Trophy className="w-5 h-5" />,
      label: 'Vittorie',
      value: history.wins,
      color: 'from-green-600 to-green-700',
    },
    {
      icon: <Target className="w-5 h-5" />,
      label: 'Sconfitte',
      value: history.losses,
      color: 'from-red-600 to-red-700',
    },
    {
      icon: <Crown className="w-5 h-5" />,
      label: 'Blackjack',
      value: history.blackjacks,
      color: 'from-purple-600 to-purple-700',
    },
  ];
  
  return (
    <div className="h-full grid grid-cols-[250px_1fr_250px] gap-8">
      <div className="space-y-3">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className={`bg-gradient-to-r ${stat.color} p-3 rounded-lg shadow-lg transform transition-all duration-300 hover:scale-105`}
          >
            <div className="flex items-center gap-3">
              <div className="text-white">{stat.icon}</div>
              <div>
                <div className="text-white text-sm font-medium">{stat.label}</div>
                <div className="text-white font-bold">{stat.value}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="flex flex-col justify-between">
        <div className="dealer-area">
          <h2 className="text-yellow-300 text-center text-2xl mb-4 font-wow">Banco</h2>
          <Hand 
            cards={dealer.hand} 
            isDealer={true} 
            animatingCard={animatingCard} 
          />
        </div>
        
        <Message message={message} gameStatus={gameStatus} />
        
        <div className="player-area">
          <h2 className="text-yellow-300 text-center text-2xl mb-4 font-wow">Giocatore</h2>
          <Hand 
            cards={player.hand} 
            animatingCard={animatingCard} 
          />
        </div>
      </div>
      
      <div className="flex flex-col justify-center">
        {gameStatus === 'betting' ? (
          <BettingControls 
            bet={bet} 
            chips={chips} 
            onBetChange={handleBet} 
            onDeal={handleDeal} 
          />
        ) : (
          <Controls 
            onAction={dispatch} 
            gameStatus={gameStatus} 
            canDouble={canDouble} 
          />
        )}
      </div>
    </div>
  );
};

export default Game;