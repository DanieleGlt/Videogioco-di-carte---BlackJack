import React from 'react';
import { useBlackjack } from '../hooks/useBlackjack';
import { Coins, Trophy, Crown, Target } from 'lucide-react';

const Stats: React.FC = () => {
  const { gameState } = useBlackjack();
  const { chips, history } = gameState;

  const stats = [
    {
      icon: <Coins className="w-5 h-5" />,
      label: 'Chips',
      value: `$${chips}`,
      color: 'from-yellow-600 to-yellow-700',
    },
    {
      icon: <Trophy className="w-5 h-5" />,
      label: 'Wins',
      value: history.wins,
      color: 'from-green-600 to-green-700',
    },
    {
      icon: <Target className="w-5 h-5" />,
      label: 'Losses',
      value: history.losses,
      color: 'from-red-600 to-red-700',
    },
    {
      icon: <Crown className="w-5 h-5" />,
      label: 'Blackjacks',
      value: history.blackjacks,
      color: 'from-purple-600 to-purple-700',
    },
  ];

  return (
    <div className="space-y-3">
      {stats.map((stat, index) => (
        <div
          key={stat.label}
          className={`bg-gradient-to-r ${stat.color} p-3 rounded-lg shadow-lg stats-item`} // Aggiungi una classe per lo stile specifico
        >
          <div className="flex items-center gap-3">
            <div className="text-white">{stat.icon}</div>
            <div>
              <div className="text-white text-sm font-medium font-wow">{stat.label}</div> {/* Usa il font WoW */}
              <div className="text-white font-bold font-wow">{stat.value}</div> {/* Usa il font WoW */}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Stats;