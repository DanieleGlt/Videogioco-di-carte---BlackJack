import React from 'react';
import { Card as CardType } from '../types';
import Card from './Card';
import { calculateScore } from '../utils/cardUtils';

interface HandProps {
  cards: CardType[];
  isDealer?: boolean;
  showScore?: boolean;
  animatingCard?: boolean;
}

const Hand: React.FC<HandProps> = ({ 
  cards, 
  isDealer = false, 
  showScore = true,
  animatingCard = false 
}) => {
  const score = calculateScore(cards);
  
  return (
    <div className="flex flex-col items-center justify-center gap-2">
      {showScore && (
        <div 
          className={`text-white text-xl font-bold px-4 py-1 rounded-full 
            ${score > 21 ? 'bg-red-600' : score === 21 ? 'bg-yellow-500' : 'bg-blue-600'}
            transition-all duration-300 ${cards.length ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}
        >
          {score > 0 ? score : ''}
        </div>
      )}
      
      <div className="flex justify-center items-center relative h-40 sm:h-44">
        {cards.length === 0 ? (
          <div className="w-24 h-32 sm:w-28 sm:h-36 border-2 border-dashed border-gray-400 rounded-lg flex items-center justify-center text-gray-400">
            No cards
          </div>
        ) : (
          cards.map((card, index) => (
            <Card 
              key={`${card.suit}-${card.rank}-${index}`} 
              card={card} 
              index={index} 
              isDealer={isDealer}
              animatingCard={animatingCard} 
            />
          ))
        )}
      </div>
    </div>
  );
};

export default Hand;