import React, { useState, useEffect } from 'react';
import { Card as CardType, Suit } from '../types';
import { getSuitSymbol, isRedSuit } from '../utils/cardUtils';

interface CardProps {
  card: CardType;
  index: number;
  isDealer?: boolean;
  animatingCard?: boolean;
}

const Card: React.FC<CardProps> = ({ card, index, isDealer = false, animatingCard = false }) => {
  const [flipped, setFlipped] = useState(!!card.hidden);
  const [animated, setAnimated] = useState(false);
  
  useEffect(() => {
    // Flip card when hidden status changes
    if (flipped !== !!card.hidden) {
      setFlipped(!!card.hidden);
    }
    
    // Animation delay based on card index
    const delay = index * 100;
    setTimeout(() => {
      setAnimated(true);
    }, delay);
    
    return () => {
      setAnimated(false);
    };
  }, [card.hidden, flipped, index]);
  
  const getSuitColor = (suit: Suit) => {
    return isRedSuit(suit) ? 'text-red-600' : 'text-blue-900';
  };
  
  const getCardClasses = () => {
    const baseClasses = 'relative w-24 h-32 sm:w-28 sm:h-36 rounded-lg shadow-lg overflow-hidden transform transition-all duration-500';
    const animationClasses = animated 
      ? `translate-y-0 opacity-100 rotate-0` 
      : `${isDealer ? '-translate-y-20' : 'translate-y-20'} opacity-0 ${index % 2 === 0 ? 'rotate-6' : '-rotate-6'}`;
    
    return `${baseClasses} ${animationClasses}`;
  };
  
  return (
    <div 
      className={getCardClasses()}
      style={{ 
        zIndex: index,
        marginLeft: index > 0 ? '-1rem' : '0'
      }}
    >
      <div className={`card-inner w-full h-full transition-transform duration-500 ${flipped ? 'rotate-y-180' : ''}`}>
        {/* Card Front */}
        <div className="card-front absolute w-full h-full bg-white border-2 border-gray-300 rounded-lg p-2 flex flex-col justify-between">
          <div className={`flex justify-between items-center ${getSuitColor(card.suit)}`}>
            <div className="text-lg font-semibold">{card.rank}</div>
            <div className="text-xl">{getSuitSymbol(card.suit)}</div>
          </div>
          
          <div className={`text-4xl flex justify-center items-center ${getSuitColor(card.suit)}`}>
            {getSuitSymbol(card.suit)}
          </div>
          
          <div className={`flex justify-between items-center ${getSuitColor(card.suit)}`}>
            <div className="text-xl rotate-180">{getSuitSymbol(card.suit)}</div>
            <div className="text-lg font-semibold rotate-180">{card.rank}</div>
          </div>
        </div>
        
        {/* Card Back */}
        <div className="card-back absolute w-full h-full bg-gradient-to-br from-indigo-900 to-purple-900 border-2 border-gray-300 rounded-lg flex justify-center items-center rotate-y-180">
          <div className="w-4/5 h-4/5 border-2 border-yellow-500 rounded-lg flex justify-center items-center bg-indigo-800">
            <div className="text-yellow-500 text-3xl transform rotate-45">♠</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;