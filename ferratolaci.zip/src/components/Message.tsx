import React from 'react';

interface MessageProps {
  message: string;
  gameStatus: string;
}

const Message: React.FC<MessageProps> = ({ message, gameStatus }) => {
  const getMessageClass = () => {
    if (message.includes('win') || message.includes('Blackjack')) {
      return 'bg-green-600';
    } else if (message.includes('Busted') || message.includes('lose') || message.includes('Dealer wins')) {
      return 'bg-red-600';
    } else if (message.includes('Push')) {
      return 'bg-blue-600';
    } else {
      return 'bg-indigo-800';
    }
  };
  
  return (
    <div className={`message-wow ${getMessageClass()} ${message ? 'show' : 'hide'}`}>
  {message}
</div>
  );
};

export default Message;